package com.example.seckilldemo.utils;

import com.example.seckilldemo.entity.TUser;
import com.example.seckilldemo.vo.RespBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONObject;
import springfox.documentation.spring.web.json.Json;


import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.*;

/**
 * 生成用户工具类
 */
public class UserUtil {
    public static void createUser(int count) throws Exception {
        List<TUser> tUsers = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            TUser tUser = new TUser();
            tUser.setId(13000000000L+i);
            tUser.setNickname("tUser"+1);
            tUser.setSalt("1a2b3c4d");
            tUser.setPassword(MD5Util.inputPassToDBPass("123456",tUser.getSalt()));
            tUser.setLoginCount(1);
            tUser.setRegisterDate(new Date());
            tUsers.add(tUser);



        }
        System.out.println("create tUser");
        //插入数据库
        Connection conn = getConn();
        String sql = "insert into t_user(login_count,nickname,register_date,salt,password,id) values(?,?,?,?,?,?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        for (int i = 0; i < tUsers.size(); i++) {
            TUser tUser= tUsers.get(i);
            pstmt.setInt(1,tUser.getLoginCount());
            pstmt.setString(2,tUser.getNickname());
            pstmt.setTimestamp(3,new Timestamp(tUser.getRegisterDate().getTime()));
            pstmt.setString(4,tUser.getSalt());
            pstmt.setString(5,tUser.getPassword());
            pstmt.setLong(6,tUser.getId());
            pstmt.addBatch();
        }
        pstmt.executeBatch();
        pstmt.clearParameters();
        conn.close();
        System.out.println("insert to db");

//        登录生成userTicket
        String urlString = "http://localhost:8101/login/doLogin";
        File file = new File("C:\\Users\\asus\\Desktop\\config.txt");
        if (file.exists()){
            file.delete();
        }
        RandomAccessFile raf = new RandomAccessFile(file,"rw");
        raf.seek(0);
        for (int i = 0; i < tUsers.size(); i++) {
            TUser user= tUsers.get(i);
            URL url = new URL(urlString);
            HttpURLConnection co = (HttpURLConnection) url.openConnection();
            co.setRequestMethod("POST");
            co.setDoOutput(true);
            OutputStream out = co.getOutputStream();
            String params = "mobile=" + user.getId()+ "&password=d3b1294a61a07da9b49b6e22b2cbd7f9" ;
            out.write(params.getBytes());
            out.flush();
            InputStream inputStream = co.getInputStream();
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            byte[] buff = new byte[1024];
            int len = 0;
            while ((len=inputStream.read(buff))>=0){
                bout.write(buff,0,len);
            }
            inputStream.close();
            bout.close();
            String respone = new String(bout.toByteArray());
            ObjectMapper mapper = new ObjectMapper();
            RespBean respBean = mapper.readValue(respone, RespBean.class);
            String userTicket = (String) respBean.getObject();
            System.out.println("create userTicket:"+user.getId());

            String row = user.getId()+","+userTicket;
            raf.seek(raf.length());
            raf.write(row.getBytes());
            raf.write("\r\n".getBytes());
            System.out.println("write to file :"+user.getId());

        }
        raf.close();
        System.out.println("over");

    }

    private static Connection getConn() throws Exception {
        String url = "jdbc:mysql://127.0.0.1:3306/seckill?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
        String username = "root";
        String password = "123456";
        String dirver = "com.mysql.cj.jdbc.Driver";
        Class.forName(dirver);
        return DriverManager.getConnection(url,username,password);
    }

    public static void main(String[] args) throws Exception {
        createUser(500);
    }


}
