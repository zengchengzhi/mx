package com.example.seckilldemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.seckilldemo.entity.TOrder;

/**
 *  Mapper 接口

 */
public interface TOrderMapper extends BaseMapper<TOrder> {

}
