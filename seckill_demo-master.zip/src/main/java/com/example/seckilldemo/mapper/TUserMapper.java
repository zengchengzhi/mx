package com.example.seckilldemo.mapper;

import com.example.seckilldemo.entity.TUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**

 * 用户表 Mapper 接口

 */
public interface TUserMapper extends BaseMapper<TUser> {

}
